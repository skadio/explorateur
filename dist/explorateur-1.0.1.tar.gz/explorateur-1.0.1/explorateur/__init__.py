from explorateur._version import __version__
